class AddAdveridToAdd < ActiveRecord::Migration[6.1]
  def change
    add_column :adds, :adverid, :integer
    add_index :adds, :adverid
  end
end
