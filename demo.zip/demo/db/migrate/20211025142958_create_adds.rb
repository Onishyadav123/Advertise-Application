class CreateAdds < ActiveRecord::Migration[6.1]
  def change
    create_table :adds do |t|
      t.string :ad
      t.string :title
      t.string :detail
      

      t.timestamps
    end
  end
end
