Rails.application.routes.draw do
  resources :comments
  resources :adds
  resources :advertisements
  resources :advertises
  devise_for :users
  #get 'home/index'
  root 'home#index'
  
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
