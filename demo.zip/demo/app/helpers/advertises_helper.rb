module AdvertisesHelper
end
