class Add < ApplicationRecord
	
end
