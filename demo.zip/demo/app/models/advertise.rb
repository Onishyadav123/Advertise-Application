class Advertise < ApplicationRecord
end
