**Advertise App
this Application is on ruby on rails .......
Firstly, User have to Register Themself so, that they could use the application here then after login 
After Successfull Signup we have reached at the home page of my application where the navbar have following links Home ,Edit Profile ,CreatePost,post,logout etc
user create advertisement after click on create  and see post on post link ,edit his profile and change password on edit profile link .
At Post page user can show edit delete comment on post 

